{-# OPTIONS_GHC -F -pgmF hspec-discover #-}
--{-# OPTIONS_GHC -F -pgmF hspec-discover -optF --module-name=Spec #-}
--HPC Legend:   green means always true, red means always false, yellow means never executed.
